filas_A = int(input("Ingrese el número de filas de la matriz A: "))
columnas_A = int(input("Ingrese el número de columnas de la matriz A: "))
matriz_A = []

filas_B = int(input("Ingrese el número de filas de la matriz B: "))
columnas_B = int(input("Ingrese el número de columnas de la matriz B: "))
matriz_B = []

for i in range(filas_A):
    fila = []
    for j in range(columnas_A):
        fila.append(float(input(f"Ingrese el elemento A[{i+1}][{j+1}]: ")))
    matriz_A.append(fila)

for i in range(filas_B):
    fila = []
    for j in range(columnas_B):
        fila.append(float(input(f"Ingrese el elemento B[{i+1}][{j+1}]: ")))
    matriz_B.append(fila)

if filas_A == filas_B and columnas_A == columnas_B:
    matriz_suma = [[matriz_A[i][j] + matriz_B[i][j] for j in range(columnas_A)] for i in range(filas_A)]
else:
    matriz_suma = None

matriz_multiplicacion = [[0 for j in range(columnas_A)] for i in range(filas_B)]
for i in range(filas_B):
    for j in range(columnas_A):
        for k in range(columnas_B):
            matriz_multiplicacion[i][j] += matriz_B[i][k] * matriz_A[k][j]

print("3A:")
for fila in matriz_A:
    print([3 * elemento for elemento in fila])

print("4B:")
for fila in matriz_B:
    print([4 * elemento for elemento in fila])

if matriz_suma:
    print("A + B:")
    for fila in matriz_suma:
        print(fila)

print("B x A:")
for fila in matriz_multiplicacion:
    print(fila)
