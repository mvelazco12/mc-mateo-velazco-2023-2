n = int(input("Ingrese la longitud de los vectores: "))
vector1 = []
vector2 = []

for i in range(n):
    vector1.append(float(input(f"Ingrese el valor {i+1} del primer vector: ")))
for i in range(n):
    vector2.append(float(input(f"Ingrese el valor {i+1} del segundo vector: ")))

producto_escalar = sum(vector1[i] * vector2[i] for i in range(n))
print("El producto escalar de los dos vectores es:", producto_escalar)
